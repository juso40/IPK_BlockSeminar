//Justin Sostmann
#ifndef VEC2D_H
#define VEC2D_H

class Vec2D 
{
public:
    Vec2D(int x, int y) :
        x(x), y(y) {}

	int x;
	int y;
};

#endif
