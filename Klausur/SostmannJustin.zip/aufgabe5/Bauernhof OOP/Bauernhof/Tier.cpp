//Justin Sostmann
#include "Tier.h"


Tier::Tier(Terminal& term): _term(term)
{
    
}